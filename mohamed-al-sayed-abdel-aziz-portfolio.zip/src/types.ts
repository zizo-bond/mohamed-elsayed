export interface Book {
  id: string;
  title: string;
  type: string; // 'رواية' | 'سيناريو' | 'كتاب' | 'مجموعة قصصية'
  year?: string;
  price: number;
  description: string;
  image: string; // Dynamic elegant thumbnail gradient or custom URL
}

export interface CartItem {
  book: Book;
  quantity: number;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
}

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { 
  getFirestore, 
  collection, 
  getDocs, 
  writeBatch, 
  doc 
} from "firebase/firestore";
import { Book } from "./types";

const firebaseConfig = {
  apiKey: "AIzaSyBI55vGsSXvARv-Y4nKhaxgB8-8nQrU2r8",
  authDomain: "gen-lang-client-0446040294.firebaseapp.com",
  projectId: "gen-lang-client-0446040294",
  storageBucket: "gen-lang-client-0446040294.firebasestorage.app",
  messagingSenderId: "1067224146338",
  appId: "1:1067224146338:web:8a5bf85ca1adb83a3b92fb"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);

// Initialize Firestore (with the custom database ID provided in the config)
export const db = getFirestore(app, "ai-studio-mohamedalsayedab-e3c83435-3653-4f4b-adae-98b60f23984f");

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Seed Books if they don't exist
export async function seedBooksIfEmpty() {
  try {
    const booksCol = collection(db, "books");
    let snapshot;
    try {
      snapshot = await getDocs(booksCol);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, "books");
      return;
    }
    
    if (snapshot.empty) {
      const initialBooks: Omit<Book, "id">[] = [
        {
          title: "سينما ريالتو",
          type: "رواية",
          year: "2026",
          price: 150,
          description: "رواية سينمائية ساحرة تدور أحداثها في وسط البلد بالقاهرة، حيث يتقاطع التاريخ مع الحكايات المفقودة لرواد سينما ريالتو العريقة في سرد فلسفي بديع.",
          image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400"
        },
        {
          title: "حلم البارون الأخير",
          type: "رواية",
          year: "2025",
          price: 180,
          description: "رحلة فلسفية داخل أروقة قصر البارون بمصر الجديدة، يمتزج فيها الماضي بالواقع الساحر، حيث يتتبع الكاتب الأسرار النفسية والروحية لساكني القصر.",
          image: "https://images.unsplash.com/photo-1531988042231-d39a9cc12a9a?auto=format&fit=crop&q=80&w=400"
        },
        {
          title: "جريفونيا",
          type: "سيناريو",
          year: "2022",
          price: 200,
          description: "نص سينمائي ملحمي مذهل يغوص في عوالم الفانتازيا والتشويق النفسي الدقيق، طارحاً تساؤلات وجودية حول الصراع الأزلي بين الواقع والخيال.",
          image: "https://images.unsplash.com/photo-1478720143022-385f704d3b6f?auto=format&fit=crop&q=80&w=400"
        },
        {
          title: "ملحمة أم المماليك",
          type: "رواية",
          year: "2021",
          price: 160,
          description: "رواية تاريخية ملحمية ترصد صراع القوى في مصر المملوكية، وتكشف بتفاصيل لغوية فخمة عن الصراعات النفسية والإنسانية العميقة خلف جدران القصور العتيقة.",
          image: "https://images.unsplash.com/photo-1461360370896-922624d12aa1?auto=format&fit=crop&q=80&w=400"
        },
        {
          title: "الأصل والفصل",
          type: "كتاب",
          price: 120,
          description: "دراسة فكرية وعميقة تبحث في الجذور الثقافية والهوية المصرية عبر العصور، برؤية تحليلية تجمع بين علم الاجتماع والأنثروبولوجيا والأدب.",
          image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=400"
        },
        {
          title: "ميزان من ذهب",
          type: "مجموعة قصصية",
          price: 110,
          description: "مجموعة من القصص القصيرة المكثفة، حائز بعضها على جوائز أدبية رفيعة، ترسم ببراعة لغوية مواقف إنسانية معقدة ولحظات تجلي نفسية فريدة.",
          image: "https://images.unsplash.com/photo-1476275466078-4007374efbbe?auto=format&fit=crop&q=80&w=400"
        },
        {
          title: "نصف كائن",
          type: "مجموعة قصصية",
          price: 100,
          description: "قصص غريبة سريالية تحلل النفس البشرية بين الواقع والخيال، متسائلة عن ماهية الكينونة والوعي في عصر منقسم وغامض.",
          image: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400"
        }
      ];
 
      const batch = writeBatch(db);
      initialBooks.forEach((bookData) => {
        const newDocRef = doc(collection(db, "books"));
        batch.set(newDocRef, bookData);
      });
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, "books");
        return;
      }
      console.log("Firestore successfully seeded with books data!");
    }
  } catch (error) {
    console.error("Error seeding books data: ", error);
  }
}

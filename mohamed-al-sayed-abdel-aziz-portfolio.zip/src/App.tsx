import React, { useState, useEffect } from "react";
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  User 
} from "firebase/auth";
import { 
  collection, 
  getDocs, 
  addDoc, 
  doc, 
  setDoc, 
  getDoc 
} from "firebase/firestore";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShoppingBag, 
  User as UserIcon, 
  LogOut, 
  X, 
  Plus, 
  Minus, 
  Trash2, 
  Check, 
  BookOpen, 
  Award, 
  Mail, 
  MessageSquare, 
  Send,
  Lock,
  ChevronLeft,
  ChevronRight,
  Info,
  Calendar,
  DollarSign
} from "lucide-react";

import { auth, db, seedBooksIfEmpty, handleFirestoreError, OperationType } from "./firebase";
import { Book, CartItem } from "./types";

export default function App() {
  // Authentication State
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);

  // E-commerce Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [checkoutResult, setCheckoutResult] = useState<any>(null);

  // Books State
  const [books, setBooks] = useState<Book[]>([]);
  const [booksLoading, setBooksLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState<string>("الكل");
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  // Toast Notifications
  const [toasts, setToasts] = useState<{ id: string; message: string; type: "success" | "error" }[]>([]);

  // Contact Form State
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactMsg, setContactMsg] = useState("");
  const [contactLoading, setContactLoading] = useState(false);

  // Add toast helper
  const addToast = (message: string, type: "success" | "error" = "success") => {
    const id = Math.random().toString();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Seed data & Load Books
  useEffect(() => {
    const initApp = async () => {
      // 1. Seed books into Firestore if it is a fresh instance
      await seedBooksIfEmpty();
      
      // 2. Fetch books from Firestore
      try {
        const booksCol = collection(db, "books");
        let snapshot;
        try {
          snapshot = await getDocs(booksCol);
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, "books");
          throw err;
        }
        const booksList = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data()
        })) as Book[];
        
        // Sort books by year descending or custom order
        setBooks(booksList);
      } catch (err) {
        console.error("Error fetching books:", err);
        addToast("عذراً، فشل تحميل الكتب من قاعدة البيانات.", "error");
      } finally {
        setBooksLoading(false);
      }
    };

    initApp();
  }, []);

  // Monitor Auth State and Load Cart from Firestore or LocalStorage
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        // Load cart from Firestore for authenticated user
        try {
          const cartRef = doc(db, "users", currentUser.uid);
          let cartSnap;
          try {
            cartSnap = await getDoc(cartRef);
          } catch (e) {
            handleFirestoreError(e, OperationType.GET, `users/${currentUser.uid}`);
            throw e;
          }
          if (cartSnap.exists() && cartSnap.data().cart) {
            setCart(cartSnap.data().cart);
          } else {
            // Merge localStorage guest cart into Firestore if exists
            const localCart = localStorage.getItem("guest_cart");
            if (localCart) {
              const parsed = JSON.parse(localCart);
              if (parsed.length > 0) {
                setCart(parsed);
                try {
                  await setDoc(cartRef, { cart: parsed, email: currentUser.email }, { merge: true });
                } catch (e) {
                  handleFirestoreError(e, OperationType.WRITE, `users/${currentUser.uid}`);
                  throw e;
                }
                localStorage.removeItem("guest_cart");
              }
            }
          }
        } catch (e) {
          console.error("Error loading user cart:", e);
        }
      } else {
        // Load cart from localStorage for guest
        const localCart = localStorage.getItem("guest_cart");
        if (localCart) {
          setCart(JSON.parse(localCart));
        } else {
          setCart([]);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Sync Cart to storage when it changes
  const updateCartState = async (newCart: CartItem[]) => {
    setCart(newCart);
    if (user) {
      try {
        const cartRef = doc(db, "users", user.uid);
        try {
          await setDoc(cartRef, { cart: newCart, email: user.email }, { merge: true });
        } catch (e) {
          handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`);
          throw e;
        }
      } catch (e) {
        console.error("Error saving user cart to Firestore:", e);
      }
    } else {
      localStorage.setItem("guest_cart", JSON.stringify(newCart));
    }
  };

  // Cart Operations
  const addToCart = (book: Book, openDrawer = false) => {
    const existing = cart.find((item) => item.book.id === book.id);
    let newCart: CartItem[] = [];
    if (existing) {
      newCart = cart.map((item) =>
        item.book.id === book.id ? { ...item, quantity: item.quantity + 1 } : item
      );
    } else {
      newCart = [...cart, { book, quantity: 1 }];
    }
    updateCartState(newCart);
    addToast(`تمت إضافة "${book.title}" إلى سلة المشتريات`);
    if (openDrawer) {
      setIsCartOpen(true);
    }
  };

  const removeFromCart = (bookId: string) => {
    const newCart = cart.filter((item) => item.book.id !== bookId);
    updateCartState(newCart);
    addToast("تمت إزالة الكتاب من السلة", "success");
  };

  const adjustQuantity = (bookId: string, delta: number) => {
    const newCart = cart.map((item) => {
      if (item.book.id === bookId) {
        const newQty = item.quantity + delta;
        return { ...item, quantity: newQty < 1 ? 1 : newQty };
      }
      return item;
    });
    updateCartState(newCart);
  };

  // Auth Operations
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthLoading(true);

    try {
      if (authMode === "login") {
        await signInWithEmailAndPassword(auth, email, password);
        addToast("تم تسجيل الدخول بنجاح! أهلاً بك.");
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
        addToast("تم إنشاء الحساب وتسجيل الدخول بنجاح!");
      }
      setShowAuthModal(false);
      setEmail("");
      setPassword("");
    } catch (err: any) {
      console.error(err);
      let errMsg = "حدث خطأ ما، يرجى المحاولة لاحقاً.";
      if (err.code === "auth/wrong-password" || err.code === "auth/user-not-found") {
        errMsg = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
      } else if (err.code === "auth/email-already-in-use") {
        errMsg = "هذا البريد الإلكتروني مسجل بالفعل.";
      } else if (err.code === "auth/invalid-email") {
        errMsg = "البريد الإلكتروني غير صالح.";
      } else if (err.code === "auth/weak-password") {
        errMsg = "كلمة المرور ضعيفة جداً (يجب ألا تقل عن 6 أحرف).";
      }
      setAuthError(errMsg);
      addToast(errMsg, "error");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      addToast("تم تسجيل الخروج بنجاح.");
    } catch (e) {
      console.error(e);
    }
  };

  // Checkout API handler
  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setCheckoutLoading(true);
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          items: cart,
          email: user?.email || "guest@novelist.com"
        })
      });

      const data = await response.json();
      if (data.success) {
        setCheckoutResult(data);
        // Clear cart
        await updateCartState([]);
        setIsCartOpen(false);
        addToast("تم إنشاء الفاتورة الآمنة بنجاح", "success");
      } else {
        addToast(data.message || "فشلت عملية الدفع", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("خطأ في الاتصال بالخادم لإتمام الدفع.", "error");
    } finally {
      setCheckoutLoading(false);
    }
  };

  // Contact Form Submission
  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMsg) {
      addToast("يرجى ملء جميع الحقول المطلوبة.", "error");
      return;
    }
    setContactLoading(true);
    try {
      // Save contact message to firestore
      try {
        await addDoc(collection(db, "contacts"), {
          name: contactName,
          email: contactEmail,
          message: contactMsg,
          timestamp: new Date()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.CREATE, "contacts");
        throw e;
      }
      addToast("شكراً لرسالتك! سيقوم الكاتب بالرد عليك قريباً.", "success");
      setContactName("");
      setContactEmail("");
      setContactMsg("");
    } catch (e) {
      console.error(e);
      addToast("فشل إرسال الرسالة، يرجى المحاولة لاحقاً.", "error");
    } finally {
      setContactLoading(false);
    }
  };

  // Filter books list
  const filteredBooks = selectedFilter === "الكل" 
    ? books 
    : books.filter((b) => b.type === selectedFilter || (selectedFilter === "كتب وقصص" && (b.type === "كتاب" || b.type === "مجموعة قصصية")));

  const totalCartAmount = cart.reduce((total, item) => total + (item.book.price * item.quantity), 0);
  const totalCartCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-dark-main text-light selection:bg-gold selection:text-dark-main relative overflow-x-hidden font-sans">
      
      {/* Dynamic Toast Notifications */}
      <div className="fixed top-24 left-6 z-50 flex flex-col gap-3 max-w-sm">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, x: -30, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -20, scale: 0.9 }}
              transition={{ duration: 0.3 }}
              className={`p-4 rounded-lg border flex items-center gap-3 backdrop-blur-md shadow-lg ${
                toast.type === "success" 
                  ? "bg-dark-card/90 border-gold/40 text-gold shadow-gold/10" 
                  : "bg-red-950/90 border-red-500/40 text-red-200"
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${toast.type === "success" ? "bg-gold" : "bg-red-500"}`} />
              <p className="text-sm font-medium">{toast.message}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* STICKY HEADER & NAVIGATION */}
      <header id="header" className="sticky top-0 z-40 bg-dark-main border-b border-gold/30 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-12 h-20 flex items-center justify-between">
          
          {/* Right Side: Logo */}
          <div className="flex items-center gap-4">
            <a href="#" className="flex flex-col">
              <span className="font-serif text-2xl font-bold tracking-wide text-gold hover:opacity-90 transition-opacity">
                محمد السيد عبد العزيز
              </span>
              <span className="text-[10px] font-serif tracking-[0.15em] uppercase text-gold/60 mr-1">
                روائي وقاص مصري
              </span>
            </a>
          </div>

          {/* Middle: Elegant Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-serif tracking-wide text-light/85">
            <a href="#" className="hover:text-gold transition-colors duration-200">الرئيسية</a>
            <a href="#about" className="hover:text-gold transition-colors duration-200">عن الكاتب</a>
            <a href="#library" className="hover:text-gold transition-colors duration-200">إصداراتي</a>
            <a href="#awards" className="hover:text-gold transition-colors duration-200">الجوائز</a>
            <a href="#contact" className="hover:text-gold transition-colors duration-200">تواصل</a>
          </nav>

          {/* Left Side: Auth & Shopping Cart */}
          <div className="flex items-center gap-6">
            
            {/* Shopping Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-2 border border-gold/50 px-4 py-1.5 rounded-full text-xs text-gold hover:bg-gold/5 transition-all cursor-pointer"
            >
              <ShoppingBag size={13} className="text-gold" />
              <span className="font-serif font-bold">السلة</span>
              <span className="bg-gold text-dark-main w-4 h-4 flex items-center justify-center rounded-full text-[10px] font-bold">
                {totalCartCount}
              </span>
            </button>

            {/* Dynamic User Profile / Login */}
            {user ? (
              <div className="flex items-center gap-3 bg-dark-card border border-gold/20 rounded-full px-4 py-1.5 text-xs text-light">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="max-w-[120px] truncate hidden sm:inline">{user.email}</span>
                <button 
                  onClick={handleLogout}
                  title="تسجيل الخروج"
                  className="hover:text-gold text-light/60 transition-colors p-1"
                >
                  <LogOut size={14} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => { setAuthMode("login"); setShowAuthModal(true); }}
                className="bg-gold text-dark-main text-xs font-bold px-5 py-2 rounded shadow-lg shadow-gold/10 hover:bg-[#B49027] transition-all cursor-pointer"
              >
                دخول
              </button>
            )}
          </div>
        </div>
      </header>

      {/* HERO SECTION */}
      <section id="hero" className="relative w-full min-h-[85vh] flex items-center justify-center overflow-hidden">
        {/* Background Image with absolute overlay gradient */}
        <div className="absolute inset-0 z-0">
          <img
            id="hero-image"
            src="/src/assets/images/hero_author_1782554708878.jpg"
            onError={(e) => {
              e.currentTarget.src = "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&q=80&w=1600";
            }}
            alt="الروائي محمد السيد عبد العزيز"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-105 filter brightness-90 animate-[zoom_60s_infinite_alternate]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-main via-dark-main/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-l from-dark-main/30 via-transparent to-dark-main/30" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center mt-12">
          {/* Subtle Watermark behind text */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.06] text-[150px] sm:text-[220px] font-bold text-gold select-none pointer-events-none font-serif z-0">
            سرد
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6 relative z-10"
          >
            <span className="text-gold text-xs uppercase tracking-[0.25em] mb-2 block font-serif">
              روائي وقاص مصري
            </span>
            
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-bold text-white tracking-tight leading-tight md:leading-[1.15]">
              سرد يلامس الوجدان <br />
              <span className="text-gold-gradient">ويطرح تساؤلات الوجود</span>
            </h1>

            <div className="max-w-xl mx-auto py-2">
              <p className="text-[#EAEAEA]/85 text-sm md:text-base leading-relaxed italic border-r-2 border-gold pr-4 text-right">
                "مشروعي الأدبي يجمع بين العمق الفني والجمال اللغوي، موظفاً الفانتازيا والواقعية السحرية ليسرد حكايات تلامس وجدان القارئ وتثير لديه التساؤلات الفلسفية."
              </p>
            </div>

            <p className="max-w-2xl mx-auto text-light/70 text-sm md:text-base leading-relaxed font-light">
              مرحباً بكم في الصالون الأدبي للروائي والقاصّ المصري محمد السيد عبد العزيز. رحلة في عوالم الفانتازيا الفلسفية التي تأسر القلوب وتوقظ الفكر.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <a
                href="#library"
                className="w-full sm:w-auto bg-gold hover:bg-[#B49027] text-dark-main font-bold px-8 py-3 rounded shadow-lg shadow-gold/10 transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer"
              >
                <span>اكتشف أعمالي</span>
                <ChevronLeft size={16} className="transform group-hover:-translate-x-1 transition-transform" />
              </a>
              <a
                href="#about"
                className="w-full sm:w-auto border border-gold text-gold hover:bg-gold/5 font-bold px-8 py-3 rounded transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>عن الكاتب</span>
              </a>
            </div>
          </motion.div>
        </div>

        {/* Elegant scroll down indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 hidden md:flex flex-col items-center gap-2 opacity-50">
          <span className="text-[10px] font-mono tracking-widest text-gold uppercase">اسحب للأسفل</span>
          <div className="w-5 h-8 border-2 border-gold/30 rounded-full flex justify-center p-1">
            <motion.div 
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
              className="w-1 h-2 bg-gold rounded-full"
            />
          </div>
        </div>
      </section>

      {/* ABOUT THE AUTHOR SECTION */}
      <section id="about" className="py-24 border-t border-gold/30 bg-[#0D0D12] relative">
        <div className="max-w-7xl mx-auto px-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Bio Column */}
            <div className="lg:col-span-7 space-y-8">
              <div className="space-y-2">
                <span className="text-gold font-serif text-xs uppercase tracking-[0.2em] mb-2 block">من أنا</span>
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-white">من هو محمد السيد عبد العزيز؟</h2>
                <div className="w-16 h-[1px] bg-gold/50" />
              </div>

              <p className="text-[#EAEAEA]/95 text-lg leading-relaxed font-serif font-light">
                صيدلي، وروائي مصري يرتكز مشروعه على تقديم أعمال تجمع بين العمق الفني والجمال اللغوي. أسعى من خلال كتاباتي إلى سرد حكايات تلامس وجدان القارئ وتثير لديه التساؤلات الفلسفية والوجودية، موظفاً الفانتازيا والواقعية السحرية.
              </p>

              {/* Awards Box */}
              <div id="awards" className="bg-[#1A1A24] border border-[#D4AF37]/30 p-5 rounded flex items-center gap-4 hover:border-[#D4AF37]/50 transition-all shadow-lg shadow-[#D4AF37]/5">
                <div className="text-3xl p-2 bg-dark-main rounded border border-gold/20">🏆</div>
                <div>
                  <h4 className="text-[#D4AF37] text-xs font-serif font-bold tracking-[0.1em] uppercase mb-1">جائزة iRead</h4>
                  <p className="text-[#EAEAEA] text-sm leading-relaxed font-serif">
                    أفضل قصة قصيرة عن عمل <span className="text-gold underline underline-offset-4 font-bold">"حبيس الزمن"</span>
                  </p>
                  <p className="text-[10px] text-light/40 mt-1 font-serif">
                    المنصة العربية الأكبر المعنية برعاية وتقدير الإبداع الأدبي في مصر والوطن العربي.
                  </p>
                </div>
              </div>
            </div>

            {/* Showcase Visual column */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative group max-w-md w-full">
                {/* Decorative glowing background frame */}
                <div className="absolute inset-0 bg-gradient-to-tr from-gold/10 to-transparent rounded blur-xl group-hover:scale-102 transition-transform duration-500" />
                
                {/* Book Collage Visual Representation */}
                <div className="relative bg-[#1A1A24] border border-gold/25 p-8 rounded shadow-xl overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-bl-full" />
                  
                  <div className="flex flex-col items-center text-center space-y-6">
                    <BookOpen size={40} className="text-gold opacity-80" />
                    
                    <h3 className="text-xl font-serif text-white font-semibold tracking-wide">بصمة أدبية فريدة</h3>
                    <p className="text-light/60 text-xs sm:text-sm leading-relaxed italic font-serif">
                      "الكتابة بالنسبة لي ليست مجرد صياغة كلمات، بل هي استكشاف للمجهول داخل الروح، ومحاولة لمسح الغبار عن الأسئلة الصامتة التي نخشى مواجهتها."
                    </p>
                    
                    <div className="w-full pt-4 border-t border-gold/10 grid grid-cols-3 gap-2 text-center font-serif">
                      <div>
                        <div className="text-gold font-bold text-lg">7+</div>
                        <div className="text-[10px] text-light/40 uppercase tracking-wider">أعمال منشورة</div>
                      </div>
                      <div>
                        <div className="text-gold font-bold text-lg">2021</div>
                        <div className="text-[10px] text-light/40 uppercase tracking-wider">بداية المشوار الأدبي</div>
                      </div>
                      <div>
                        <div className="text-gold font-bold text-lg">1</div>
                        <div className="text-[10px] text-light/40 uppercase tracking-wider">جوائز كبرى</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* LIBRARY (إصداراتي) */}
      <section id="library" className="py-24 border-t border-gold/30 bg-[#0D0D12] relative">
        <div className="max-w-7xl mx-auto px-12">
          
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div className="space-y-2">
              <span className="text-[#D4AF37] text-xs uppercase tracking-[0.2em] mb-2 block font-serif">المكتبة المختارة</span>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-white">المكتبة الرقمية وإصداراتي الأدبية</h2>
              <div className="w-16 h-[1px] bg-gold/50" />
            </div>

            {/* Filter buttons */}
            <div className="flex flex-wrap gap-2 bg-[#1A1A24] border border-[#D4AF37]/30 p-1.5 rounded">
              {["الكل", "رواية", "سيناريو", "كتب وقصص"].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-5 py-2 rounded text-xs font-serif transition-all duration-300 cursor-pointer ${
                    selectedFilter === filter 
                      ? "bg-[#D4AF37] text-[#0D0D12] font-bold" 
                      : "text-light/70 hover:text-white hover:bg-[#1A1A24]/55"
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* Skeletons or Books Grid */}
          {booksLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((n) => (
                <div key={n} className="bg-[#1A1A24] border border-gold/10 rounded h-[450px] animate-pulse p-6 space-y-6">
                  <div className="bg-[#0D0D12] rounded w-full h-[220px]" />
                  <div className="h-6 bg-[#0D0D12] rounded w-3/4" />
                  <div className="h-4 bg-[#0D0D12] rounded w-1/2" />
                  <div className="h-12 bg-[#0D0D12] rounded w-full" />
                </div>
              ))}
            </div>
          ) : filteredBooks.length === 0 ? (
            <div className="text-center py-16 bg-[#1A1A24] rounded border border-gold/10">
              <BookOpen size={48} className="text-[#D4AF37]/40 mx-auto mb-4" />
              <p className="text-light/60 font-serif">لا توجد أعمال تطابق هذا التصنيف حالياً.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBooks.map((book) => (
                <motion.div
                  key={book.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4 }}
                  className="group bg-[#1A1A24] border border-white/5 rounded-xl overflow-hidden shadow-2xl hover:border-[#D4AF37]/50 transition-all flex flex-col justify-between h-full"
                >
                  
                  {/* Card Content Top */}
                  <div>
                    {/* Book Cover Image */}
                    <div className="relative overflow-hidden h-[240px] bg-[#0D0D12] flex items-center justify-center p-4">
                      <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A24] via-transparent to-transparent z-10" />
                      <img 
                        src={book.image} 
                        alt={book.title}
                        className="w-full h-full object-cover rounded shadow-lg transition-transform duration-500 group-hover:scale-102"
                      />
                      {/* Tag & Year */}
                      <div className="absolute top-4 right-4 z-20 flex gap-2">
                        <span className="bg-[#D4AF37] text-[#0D0D12] font-serif font-bold text-[10px] px-2.5 py-1 rounded">
                          {book.type}
                        </span>
                        {book.year && (
                          <span className="bg-[#0D0D12]/85 text-[#D4AF37] text-[10px] px-2.5 py-1 rounded font-serif border border-[#D4AF37]/30">
                            {book.year}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Book Meta */}
                    <div className="p-6 space-y-3">
                      <h3 className="text-lg font-serif font-bold text-white group-hover:text-gold transition-colors duration-200">
                        {book.title}
                      </h3>
                      
                      <p className="text-light/60 text-xs sm:text-sm line-clamp-3 leading-relaxed font-serif font-light">
                        {book.description}
                      </p>
                    </div>
                  </div>

                  {/* Card Action / Price Bottom */}
                  <div className="p-6 pt-0 space-y-4">
                    <div className="flex items-center justify-between border-t border-white/5 pt-4">
                      <span className="text-light/50 text-[11px] font-serif">سعر النسخة</span>
                      <span className="text-lg font-serif font-bold text-[#D4AF37]">
                        {book.price} <span className="text-[10px] font-sans">جنيه</span>
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => addToCart(book, true)}
                        className="flex-1 bg-transparent border border-[#D4AF37] text-[#D4AF37] text-xs py-2 rounded hover:bg-[#D4AF37] hover:text-[#0D0D12] transition-all font-serif font-bold cursor-pointer text-center"
                      >
                        شراء
                      </button>
                      <button
                        onClick={() => setSelectedBook(book)}
                        className="flex-1 bg-[#1A1A24] border border-white/10 text-white text-xs py-2 rounded hover:border-[#D4AF37]/50 transition-all font-serif cursor-pointer text-center"
                      >
                        تفاصيل
                      </button>
                    </div>
                  </div>

                </motion.div>
              ))}
            </div>
          )}

        </div>
      </section>

      {/* CONTACT THE AUTHOR */}
      <section id="contact" className="py-24 border-t border-gold/5 bg-gradient-to-b from-dark-main to-dark-card relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
            
            {/* Contact Details Left */}
            <div className="lg:col-span-5 space-y-8">
              <div className="space-y-2">
                <span className="text-[#D4AF37] text-xs uppercase tracking-[0.2em] mb-2 block font-serif">تواصل مباشر</span>
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-white">تواصل مع الكاتب</h2>
                <div className="w-16 h-[1px] bg-gold/50" />
              </div>

              <p className="text-light/70 text-base leading-relaxed font-serif font-light">
                يسعد الكاتب الروائي محمد السيد عبد العزيز تلقي آرائكم النقدية، واستفساراتكم حول الإصدارات، والمشاركات في الندوات واللقاءات الثقافية والتلفزيونية.
              </p>

              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 rounded bg-[#1A1A24] border border-[#D4AF37]/20 shadow-md">
                  <div className="text-[#D4AF37] bg-[#D4AF37]/10 p-2.5 rounded border border-[#D4AF37]/20">
                    <Mail size={18} />
                  </div>
                  <div>
                    <h5 className="text-[10px] text-light/40 uppercase tracking-wider font-serif">البريد الإلكتروني المباشر</h5>
                    <p className="text-sm font-semibold text-[#D4AF37] font-serif">zizobond36@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded bg-[#1A1A24] border border-[#D4AF37]/20 shadow-md">
                  <div className="text-[#D4AF37] bg-[#D4AF37]/10 p-2.5 rounded border border-[#D4AF37]/20">
                    <MessageSquare size={18} />
                  </div>
                  <div>
                    <h5 className="text-[10px] text-light/40 uppercase tracking-wider font-serif">صالون القاهرة الثقافي</h5>
                    <p className="text-sm font-semibold text-light font-serif">رابطة الأدباء والقصاصين المصريين</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form Right */}
            <div className="lg:col-span-7 bg-[#1A1A24] p-8 rounded border border-gold/35 shadow-2xl">
              <h3 className="text-xl font-serif text-white font-bold mb-6 flex items-center gap-2">
                <Send size={16} className="text-[#D4AF37]" />
                <span>إرسال رسالة مباشرة للكاتب</span>
              </h3>

              <form onSubmit={handleContactSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-light/70 font-serif">الاسم الكامل *</label>
                    <input
                      type="text"
                      required
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="أدخل اسمك الكريم"
                      className="w-full bg-dark-main border border-gold/20 focus:border-gold rounded px-4 py-3 text-sm text-white placeholder-light/30 outline-none transition-all font-serif"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-light/70 font-serif">البريد الإلكتروني *</label>
                    <input
                      type="email"
                      required
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full bg-dark-main border border-gold/20 focus:border-gold rounded px-4 py-3 text-sm text-white placeholder-light/30 outline-none transition-all text-left font-serif"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold text-light/70 font-serif">نص الرسالة *</label>
                  <textarea
                    required
                    rows={5}
                    value={contactMsg}
                    onChange={(e) => setContactMsg(e.target.value)}
                    placeholder="اكتب انطباعك عن الروايات أو رسالتك الأدبية هنا..."
                    className="w-full bg-dark-main border border-gold/20 focus:border-gold rounded px-4 py-3 text-sm text-white placeholder-light/30 outline-none transition-all resize-none font-serif"
                  />
                </div>

                <button
                  type="submit"
                  disabled={contactLoading}
                  className="w-full bg-gold hover:bg-[#B49027] text-dark-main font-serif font-bold py-3.5 rounded transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-lg shadow-gold/10"
                >
                  {contactLoading ? (
                    <div className="w-5 h-5 border-2 border-dark-main border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send size={14} />
                      <span>إرسال الرسالة الآن</span>
                    </>
                  )}
                </button>
              </form>
            </div>

          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#0D0D12] border-t border-white/5 py-12">
        <div className="max-w-7xl mx-auto px-12 flex flex-col md:flex-row items-center justify-between gap-6 text-[10px] text-white/40 font-serif">
          <div className="flex gap-6 order-2 md:order-1">
            <a href="#" className="hover:text-gold transition-colors">فيسبوك</a>
            <a href="#" className="hover:text-gold transition-colors">انستغرام</a>
            <a href="#" className="hover:text-gold transition-colors">جودريدز</a>
          </div>
          <div className="order-1 md:order-2 text-center md:text-right">
            جميع الحقوق محفوظة © 2026 - الروائي محمد السيد عبد العزيز
          </div>
        </div>
      </footer>

      {/* SHOPPING CART DRAWER (Slide-in) */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black z-50 cursor-pointer"
            />
            {/* Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.35 }}
              className="fixed inset-y-0 right-0 w-full sm:w-[450px] bg-dark-card border-l border-gold/10 shadow-2xl z-50 flex flex-col justify-between"
            >
              {/* Header */}
              <div className="p-6 border-b border-gold/10 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <ShoppingBag className="text-gold" size={20} />
                  <h3 className="font-serif text-lg font-bold text-white">سلة المشتريات الأدبية</h3>
                  <span className="text-[10px] bg-gold/10 text-gold px-2.5 py-0.5 rounded-full font-bold">
                    {totalCartCount}
                  </span>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 rounded-lg hover:bg-dark-main text-light/60 hover:text-white transition-all"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-24 space-y-4">
                    <ShoppingBag size={48} className="text-gold/20 mx-auto" />
                    <p className="text-light/50 text-sm">السلة فارغة حالياً. تصفح المكتبة وأضف روايتك المفضلة.</p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="text-xs text-gold border border-gold/30 hover:border-gold px-4 py-2 rounded-lg transition-all"
                    >
                      تصفح المكتبة
                    </button>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div 
                      key={item.book.id}
                      className="p-4 rounded-xl bg-dark-main border border-gold/5 flex gap-4 relative group"
                    >
                      <img
                        src={item.book.image}
                        alt={item.book.title}
                        className="w-16 h-20 object-cover rounded-md bg-dark-card flex-shrink-0"
                      />
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] text-gold bg-gold/10 px-2 py-0.5 rounded-full font-bold">
                            {item.book.type}
                          </span>
                          <h4 className="text-sm font-bold text-white mt-1.5">{item.book.title}</h4>
                        </div>
                        
                        <div className="flex items-center justify-between mt-2">
                          {/* Quantity control */}
                          <div className="flex items-center border border-gold/20 rounded-md">
                            <button
                              onClick={() => adjustQuantity(item.book.id, -1)}
                              className="p-1 text-light/60 hover:text-white transition-colors"
                            >
                              <Minus size={12} />
                            </button>
                            <span className="px-3 text-xs font-mono font-bold text-gold">{item.quantity}</span>
                            <button
                              onClick={() => adjustQuantity(item.book.id, 1)}
                              className="p-1 text-light/60 hover:text-white transition-colors"
                            >
                              <Plus size={12} />
                            </button>
                          </div>

                          <span className="text-sm font-serif font-bold text-gold">
                            {item.book.price * item.quantity} جنيه
                          </span>
                        </div>
                      </div>

                      {/* Remove item button */}
                      <button
                        onClick={() => removeFromCart(item.book.id)}
                        className="absolute top-4 left-4 p-1 rounded hover:bg-red-950/20 text-light/30 hover:text-red-400 transition-all opacity-0 group-hover:opacity-100"
                        title="حذف من السلة"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {/* Footer Checkout info */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-gold/10 bg-dark-main space-y-4">
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-light/60">
                      <span>إجمالي عدد النسخ</span>
                      <span>{totalCartCount} نسخة</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-bold text-white">المجموع النهائي الآمن</span>
                      <span className="text-xl font-serif font-bold text-gold">{totalCartAmount} جنيه مصري</span>
                    </div>
                  </div>

                  <button
                    onClick={handleCheckout}
                    disabled={checkoutLoading}
                    className="w-full bg-gold hover:bg-gold/90 text-dark-main font-bold py-3.5 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-gold/10 disabled:opacity-50"
                  >
                    {checkoutLoading ? (
                      <div className="w-5 h-5 border-2 border-dark-main border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Lock size={14} />
                        <span>إتمام عملية الدفع الآمن</span>
                      </>
                    )}
                  </button>
                  <p className="text-[10px] text-center text-light/40">
                    بوابة الدفع مؤمنة عبر بروتوكول SSL مشفر بالكامل.
                  </p>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* FIREBASE AUTHENTICATION DIALOG (Modal) */}
      <AnimatePresence>
        {showAuthModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAuthModal(false)}
              className="absolute inset-0 bg-black/80 cursor-pointer"
            />
            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-dark-card border border-gold/25 rounded-3xl shadow-gold-glow p-8 z-10 space-y-6"
            >
              {/* Close Button */}
              <button
                onClick={() => setShowAuthModal(false)}
                className="absolute top-5 left-5 p-1 text-light/40 hover:text-white rounded-lg hover:bg-dark-main transition-all"
              >
                <X size={18} />
              </button>

              <div className="text-center space-y-2">
                <span className="font-serif text-lg font-bold text-gold">المنصة الأدبية للكاتب</span>
                <h3 className="text-2xl font-serif font-bold text-white">
                  {authMode === "login" ? "تسجيل دخول الأعضاء" : "إنشاء حساب جديد"}
                </h3>
                <p className="text-xs text-light/50">
                  سجل دخولك لحفظ مشترياتك ومتابعة أحدث الروايات فور صدورها.
                </p>
              </div>

              {authError && (
                <div className="p-3 bg-red-950/40 border border-red-500/20 rounded-xl text-xs text-red-300 text-center">
                  {authError}
                </div>
              )}

              <form onSubmit={handleAuthSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-light/70">البريد الإلكتروني</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full bg-dark-main border border-gold/10 focus:border-gold rounded-xl px-4 py-3 text-sm text-white placeholder-light/30 outline-none transition-all text-left"
                    dir="ltr"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-light/70">كلمة المرور</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-dark-main border border-gold/10 focus:border-gold rounded-xl px-4 py-3 text-sm text-white placeholder-light/30 outline-none transition-all text-left"
                    dir="ltr"
                  />
                </div>

                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full bg-gold hover:bg-gold/90 text-dark-main font-bold py-3 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {authLoading ? (
                    <div className="w-5 h-5 border-2 border-dark-main border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <span>{authMode === "login" ? "تسجيل الدخول" : "إنشاء الحساب"}</span>
                  )}
                </button>
              </form>

              <div className="text-center pt-2 border-t border-gold/10">
                <button
                  onClick={() => {
                    setAuthMode(authMode === "login" ? "signup" : "login");
                    setAuthError("");
                  }}
                  className="text-xs text-gold/80 hover:text-gold hover:underline"
                >
                  {authMode === "login" ? "لا تملك حساباً؟ أنشئ حساباً جديداً" : "تمتلك حساباً بالفعل؟ سجل الدخول"}
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DETAIL VIEW MODAL FOR BOOK */}
      <AnimatePresence>
        {selectedBook && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedBook(null)}
              className="absolute inset-0 bg-black cursor-pointer"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-[#1A1A24] border border-gold/30 rounded shadow-2xl p-8 z-10 overflow-hidden"
            >
              <button
                onClick={() => setSelectedBook(null)}
                className="absolute top-5 left-5 p-1 text-light/40 hover:text-white rounded hover:bg-dark-main transition-all cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Book cover left */}
                <div className="md:col-span-5">
                  <img
                    src={selectedBook.image}
                    alt={selectedBook.title}
                    className="w-full h-[300px] object-cover rounded shadow-lg border border-gold/20"
                  />
                </div>

                {/* Book details right */}
                <div className="md:col-span-7 space-y-4">
                  <div className="flex gap-2">
                    <span className="bg-[#D4AF37] text-[#0D0D12] font-serif font-bold text-[10px] px-2.5 py-1 rounded">
                      {selectedBook.type}
                    </span>
                    {selectedBook.year && (
                      <span className="bg-dark-main text-[#D4AF37] text-[10px] px-2.5 py-1 rounded font-serif border border-gold/20">
                        {selectedBook.year}
                      </span>
                    )}
                  </div>

                  <h3 className="text-2xl font-serif font-bold text-white">{selectedBook.title}</h3>
                  <div className="w-12 h-[1px] bg-gold/50" />

                  <p className="text-light/75 text-sm leading-relaxed font-serif font-light">
                    {selectedBook.description}
                  </p>

                  <div className="pt-4 flex items-center justify-between border-t border-gold/15">
                    <div>
                      <span className="text-xs text-light/45 block font-serif">سعر النسخة الأدبية</span>
                      <span className="text-2xl font-serif font-bold text-[#D4AF37]">{selectedBook.price} جنيه</span>
                    </div>
                    
                    <button
                      onClick={() => {
                        addToCart(selectedBook, true);
                        setSelectedBook(null);
                      }}
                      className="bg-[#D4AF37] hover:bg-[#B49027] text-[#0D0D12] font-serif font-bold text-sm px-6 py-2.5 rounded transition-all duration-300 cursor-pointer shadow-md shadow-gold/10"
                    >
                      شراء النسخة
                    </button>
                  </div>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* CHECKOUT RESULT MODAL (INVOICE & DUMMY GATEWAY) */}
      <AnimatePresence>
        {checkoutResult && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              exit={{ opacity: 0 }}
              onClick={() => setCheckoutResult(null)}
              className="absolute inset-0 bg-black cursor-pointer"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-lg bg-dark-card border border-emerald-500/30 rounded-3xl shadow-lg p-8 z-10 space-y-6"
            >
              <button
                onClick={() => setCheckoutResult(null)}
                className="absolute top-5 left-5 p-1 text-light/40 hover:text-white rounded-lg hover:bg-dark-main transition-all"
              >
                <X size={18} />
              </button>

              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Check size={24} />
                </div>
                <h3 className="text-2xl font-serif font-bold text-white">تم إنشاء طلب الدفع الآمن</h3>
                <p className="text-xs text-emerald-400 font-medium">
                  تم حساب القيمة الإجمالية وتأكيد مخزون الكتب بنجاح.
                </p>
              </div>

              {/* Receipt / Invoice items */}
              <div className="p-5 bg-dark-main rounded-2xl border border-gold/10 space-y-4">
                <div className="flex justify-between text-[11px] text-light/40 border-b border-gold/5 pb-2">
                  <span>تفاصيل الفاتورة الإلكترونية</span>
                  <span className="font-mono text-gold">{checkoutResult.paymentIntent.id}</span>
                </div>

                <div className="space-y-3 max-h-[150px] overflow-y-auto">
                  {checkoutResult.verifiedItems.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between items-center text-xs text-light/80">
                      <span>{item.title} (x{item.quantity})</span>
                      <span className="font-serif font-bold text-gold">{item.totalPrice} جنيه</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gold/10 pt-3 flex justify-between items-center text-sm font-bold text-white">
                  <span>المبلغ المطلوب تسديده</span>
                  <span className="text-lg font-serif text-gold">{checkoutResult.totalAmount} جنيه مصري</span>
                </div>
              </div>

              {/* Gateway integration message */}
              <div className="p-4 rounded-xl bg-gold/5 border border-gold/20 flex gap-3 text-xs leading-relaxed text-light/80">
                <Info size={18} className="text-gold shrink-0 mt-0.5" />
                <p>
                  جاهز للربط ببوابات الدفع (Stripe أو Paymob) لتلقي المدفوعات الحقيقية عبر بطاقات الائتمان ومحافظ الهاتف الذكي (Vodafone Cash، إلخ).
                </p>
              </div>

              <button
                onClick={() => setCheckoutResult(null)}
                className="w-full bg-gold hover:bg-gold/90 text-dark-main font-bold py-3.5 rounded-xl transition-all duration-300 text-center block"
              >
                متابعة تصفح الأعمال
              </button>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

/**
 * Vercel Serverless Function for handling secure e-commerce checkout.
 * Location: /api/checkout.js
 * 
 * Receives cart items, verifies prices on the server, calculates total, 
 * and generates a mock Payment Intent (compatible with Stripe or Paymob).
 */

module.exports = async (req, res) => {
  // Enable CORS
  res.setHeader("Access-Control-Allow-Credentials", true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version"
  );

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ success: false, message: "Method Not Allowed" });
  }

  try {
    const { items, email } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ 
        success: false, 
        message: "السلة فارغة أو البيانات غير صحيحة." 
      });
    }

    // Backend price catalog to prevent client-side price tampering
    const bookPrices = {
      "سينما ريالتو": 150,
      "حلم البارون الأخير": 180,
      "جريفونيا": 200,
      "ملحمة أم المماليك": 160,
      "الأصل والفصل": 120,
      "ميزان من ذهب": 110,
      "نصف كائن": 100
    };

    let totalAmount = 0;
    const verifiedItems = items.map((item) => {
      // Find book title and verify the standard price
      const title = item.book ? item.book.title : (item.title || "كتاب غير معروف");
      const price = bookPrices[title] || (item.book ? item.book.price : 100);
      const qty = item.quantity || 1;
      const itemTotal = price * qty;
      totalAmount += itemTotal;

      return {
        title,
        quantity: qty,
        unitPrice: price,
        totalPrice: itemTotal
      };
    });

    // Create unique payment intent ID
    const paymentIntentId = `pi_egy_${Math.random().toString(36).substring(2, 15)}`;
    const clientSecret = `cs_egy_secret_${Math.random().toString(36).substring(2, 25)}`;

    return res.status(200).json({
      success: true,
      message: "تم إنشاء طلب الدفع بنجاح على خادم فيرسيل الآمن.",
      paymentIntent: {
        id: paymentIntentId,
        clientSecret: clientSecret,
        amount: totalAmount * 100, // in smallest currency unit (piastres/cents)
        currency: "EGP",
        status: "requires_payment_method",
        customerEmail: email || "guest@novelist.com",
        created: Date.now()
      },
      verifiedItems,
      totalAmount,
      currency: "جنيه مصري",
      billingDetails: {
        authorName: "محمد السيد عبد العزيز",
        merchantName: "منصة الكاتب محمد السيد عبد العزيز الأدبية"
      }
    });
  } catch (error) {
    console.error("Vercel Serverless Function Error:", error);
    return res.status(500).json({ 
      success: false, 
      message: "حدث خطأ داخلي في الخادم أثناء معالجة عملية الدفع.",
      error: error.message 
    });
  }
};

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Use JSON middleware for POST requests
  app.use(express.json());

  // API Route: E-commerce Secure Checkout
  app.post("/api/checkout", (req, res) => {
    try {
      const { items, email } = req.body;

      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ 
          success: false, 
          message: "السلة فارغة أو البيانات غير صحيحة." 
        });
      }

      // Secure backend calculation of total
      let totalAmount = 0;
      const verifiedItems = items.map((item: any) => {
        // Book standard prices map for security (preventing client-side tampering)
        const bookPrices: Record<string, number> = {
          "سينما ريالتو": 150,
          "حلم البارون الأخير": 180,
          "جريفونيا": 200,
          "ملحمة أم المماليك": 160,
          "الأصل والفصل": 120,
          "ميزان من ذهب": 110,
          "نصف كائن": 100
        };

        const price = bookPrices[item.book.title] || item.book.price || 100;
        const itemTotal = price * (item.quantity || 1);
        totalAmount += itemTotal;

        return {
          title: item.book.title,
          quantity: item.quantity,
          unitPrice: price,
          totalPrice: itemTotal
        };
      });

      // Simulation of a payment gateway intent response (Stripe / Paymob compliant)
      const paymentIntent = {
        id: `pi_egy_${Math.random().toString(36).substring(2, 15)}`,
        clientSecret: `cs_egy_secret_${Math.random().toString(36).substring(2, 25)}`,
        amount: totalAmount * 100, // in cents/pinnies
        currency: "EGP",
        status: "requires_payment_method",
        customerEmail: email || "guest@novelist.com",
        created: Date.now()
      };

      return res.status(200).json({
        success: true,
        message: "تم إنشاء طلب الدفع بنجاح.",
        paymentIntent,
        verifiedItems,
        totalAmount,
        currency: "جنيه مصري",
        gatewayUrl: "https://paymob.com/api/dummy-checkout", // Example endpoint
        billingDetails: {
          authorName: "محمد السيد عبد العزيز",
          merchantName: "منصة الكاتب محمد السيد عبد العزيز الأدبية"
        }
      });
    } catch (error: any) {
      console.error("Error in checkout:", error);
      return res.status(500).json({
        success: false,
        message: "حدث خطأ أثناء معالجة الطلب.",
        error: error.message
      });
    }
  });

  // Vite middleware for asset serving in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA Fallback
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
